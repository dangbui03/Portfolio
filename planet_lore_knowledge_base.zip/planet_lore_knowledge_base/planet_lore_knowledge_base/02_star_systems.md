# 02 — Hệ sao và Thiên văn

## Câu hỏi cốt lõi
Hành tinh nhận bao nhiêu năng lượng, theo nhịp nào, và bầu trời nhìn từ mặt đất ra sao?

## Kiến thức nền
- **Loại sao và quang phổ:** ảnh hưởng phổ bức xạ, độ sáng, nhiệt độ màu và tuổi thọ sao. Không nên chỉ dùng nhãn O/B/A/F/G/K/M để kết luận hành tinh có sự sống hay không.
- **Độ sáng và khoảng cách:** lượng năng lượng nhận được phụ thuộc độ sáng sao và khoảng cách quỹ đạo; độ sáng bề mặt còn chịu tác động của khí quyển, mây và suất phản chiếu.
- **Hệ đa sao:** có thể tạo nhiều nguồn sáng, nhật thực phức tạp và biến thiên chiếu sáng; độ ổn định khí hậu phụ thuộc cấu hình quỹ đạo cụ thể.
- **Độ lệch tâm quỹ đạo:** quỹ đạo lệch tâm làm khoảng cách tới sao thay đổi theo năm; nó có thể ảnh hưởng mạnh hoặc yếu tùy đại dương, khí quyển và độ nghiêng trục.
- **Độ nghiêng trục:** là yếu tố quan trọng tạo mùa trên hành tinh có trục nghiêng.
- **Khóa thủy triều:** một bán cầu luôn hướng về sao trong trường hợp khóa 1:1 điển hình; không đồng nghĩa chắc chắn có một mặt nóng bỏng và một mặt đóng băng, vì khí quyển/đại dương có thể vận chuyển nhiệt.
- **Vệ tinh và thủy triều:** vệ tinh có thể tạo thủy triều, làm nóng bên trong qua biến dạng thủy triều và tác động đến độ nghiêng trục. Không phải hành tinh nào cũng cần mặt trăng để có thủy triều; sao chủ cũng gây thủy triều.
- **Hành tinh lang thang (rogue planet):** không quay quanh sao chủ. Có thể có nhiệt địa nhiệt và ánh sáng cục bộ, nhưng ánh sao nền thường quá yếu để chiếu sáng bề mặt như ban ngày Trái Đất.

## Nếu không có Mặt Trời hoặc Mặt Trăng thì có ánh sáng không?
Có thể có ánh sáng, nhưng phải phân biệt:
- **Ánh sáng nhìn thấy:** dung nham, hồ dung nham, cực quang, phát quang sinh học, phản ứng hóa học hoặc nguồn nhân tạo.
- **Nhiệt:** địa nhiệt có thể làm ấm một số vùng, nhưng nhiệt không tự động tạo ra ánh sáng nhìn thấy mạnh.
- **Nguồn năng lượng sinh thái:** nếu không có ánh sáng sao, quang hợp kiểu Trái Đất khó làm nền cho hệ sinh thái bề mặt; hóa tổng hợp có thể hỗ trợ các ốc đảo sinh thái.
- **Ánh sao nền/tinh vân:** tinh vân phát sáng có thể trông đẹp trên ảnh phơi sáng dài, nhưng không nên mặc định nó đủ sáng để soi rõ địa hình bằng mắt thường.
- **Cực quang:** cần các hạt năng lượng, khí quyển và điều kiện từ trường/tương tác thích hợp; không thể mặc định cực quang vĩnh cửu ở mọi hành tinh.

## Thông số cần ghi cho mỗi hành tinh
- Sao chủ: loại, khối lượng, độ sáng, tuổi ước tính, biến thiên hoạt động.
- Quỹ đạo: bán trục lớn, độ lệch tâm, chu kỳ, độ nghiêng quỹ đạo.
- Tự quay: độ dài ngày, độ nghiêng trục, trạng thái khóa thủy triều/cộng hưởng quay-quỹ đạo.
- Vệ tinh: số lượng, kích thước, quỹ đạo, tác động thủy triều.
- Bầu trời: màu sao, độ sáng ban ngày, số mặt trời nhìn thấy, nhật thực, bầu trời đêm.
- Năng lượng: ánh sáng nhận được, địa nhiệt, thủy triều, hóa năng.
- Mức chắc chắn: dữ liệu khoa học / suy luận / hư cấu.

## Tài liệu và công cụ
- NASA Exoplanet Archive: https://exoplanetarchive.ipac.caltech.edu/
- NASA Exoplanets: https://science.nasa.gov/exoplanets/
- NASA Astrobiology: https://science.nasa.gov/astrobiology/at-nasa/
- Universe Sandbox: https://universesandbox.com/
- SpaceEngine: https://spaceengine.org/
- Artifexian: https://www.youtube.com/@Artifexian
- Worldbuilding Pasta: https://worldbuildingpasta.blogspot.com/

### Cẩm nang lý thuyết Worldbuilding chuyên sâu
Artifexian (Kênh YouTube & Website): Tài nguyên số 1 cho người viết sci-fi/fantasy muốn xây dựng hệ sao. Loạt video của kênh hướng dẫn từng bước: tính toán vùng sống được, phân loại quang phổ sao, dựng quỹ đạo và lịch cho hành tinh từ toán học cơ bản.

Worldbuilding Pasta (Blog chuyên khảo): Các bài viết cực kỳ chi tiết về khí hậu học hành tinh, mô phỏng hải lưu, gió và thời tiết cho các kiểu hành tinh lạ (hành tinh khóa nhật triều, hành tinh quanh sao lùn đỏ).

Project Rho - Atomic Rockets (Trang web): Bách khoa toàn thư cho tác giả Sci-Fi cứng, đặc biệt là các mục Worldbuilding, Aliens và Astronomy.

Tough SF (Blog): Phân tích vật lý và kỹ thuật cho các kịch bản thế giới giả định khác biệt (như rogue planets, megastructures).

## Ý tưởng lore
- Một hành tinh có hai sao với màu sắc khác nhau: thay đổi ánh sáng không chỉ tạo cảnh quan mà còn ảnh hưởng nhịp sinh học và tín hiệu giao tiếp.
- Hành tinh khóa thủy triều: dải hoàng hôn là vùng có điều kiện ôn hòa hơn, nhưng gió mạnh có thể khiến việc sống ở đó nguy hiểm.
- Hành tinh lang thang: cư dân định hướng bằng địa nhiệt, phát quang sinh học và địa hình âm thanh thay vì mặt trời.
- Nhật thực có chu kỳ: tạo lịch di cư, thời kỳ săn mồi hoặc nghi lễ.

## Cảnh báo
Đừng đặt sao loại M rồi tự động kết luận hành tinh chết vì bức xạ; hoạt động sao phụ thuộc tuổi và trạng thái. Đừng đặt sao loại G rồi mặc định khí hậu giống Trái Đất. Độ sáng nhận được, khí quyển, nước, mây, phản xạ và địa chất đều cần xét cùng nhau.
