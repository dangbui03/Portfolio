# 11 — Thư viện nguồn tham khảo

## Cách dùng nguồn
Ưu tiên theo thứ tự:
1. Cơ quan khoa học và cơ sở dữ liệu chính thức cho thông số thực tế.
2. Bài nghiên cứu tổng quan hoặc sách giáo khoa cho cơ chế.
3. Phần mềm mô phỏng để trực quan hóa, nhưng kiểm tra giả định của mô hình.
4. Kênh giáo dục khoa học để làm quen chủ đề.
5. Cộng đồng worldbuilding để phản biện ý tưởng; không dùng làm nguồn cuối cùng cho tuyên bố khoa học.

Khi ghi chú, lưu: tên nguồn, URL, ngày truy cập, nội dung đã xác minh, giới hạn và cách áp dụng vào lore.

## Thiên văn và ngoại hành tinh
- NASA Exoplanet Archive — https://exoplanet.ipac.caltech.edu/
  Dữ liệu hành tinh và sao chủ; dùng để tìm ví dụ thực tế và so sánh tham số.
- NASA Exoplanets — https://science.nasa.gov/exoplanets/
  Tổng quan về ngoại hành tinh, vùng có thể tồn tại nước lỏng và phương pháp phát hiện.
- NASA Astrobiology — https://astrobiology.nasa.gov/
  Sự sống, môi trường cực hạn, khả năng sinh sống và câu hỏi hóa sinh.
- Universe Sandbox — https://universesandbox.com/
  Mô phỏng trực quan tương tác hấp dẫn và hệ hành tinh.
- SpaceEngine — https://spaceengine.org/
  Khám phá vũ trụ 3D, hữu ích cho tham khảo hình ảnh và bầu trời.
- Artifexian — https://www.youtube.com/@Artifexian
  Hướng dẫn worldbuilding định lượng; xem như tài liệu học tập, kiểm tra công thức với nguồn khoa học khi cần độ chính xác cao.

## Địa chất và cổ địa lý
- GPlates — https://www.gplates.org/
  Phần mềm mã nguồn mở để xem và tái dựng chuyển động mảng kiến tạo qua thời gian.
- GPlates User Manual — https://www.gplates.org/docs/user-manual/
  Tài liệu thao tác chính thức.
- Ancient Earth Globe — https://dinosaurpictures.org/ancient-earth
  Trực quan hóa lục địa trong các mốc thời gian địa chất.
- USGS — https://www.usgs.gov/science/science-explorer/geology
  Tài nguyên địa chất và giải thích cơ chế.
- Robert Hazen, *The Story of Earth*
  Bối cảnh về đồng tiến hóa của Trái Đất, khoáng vật và sự sống.

## Khí hậu và môi trường
- NASA GISS — https://www.giss.nasa.gov/
  Mô hình khí hậu và nghiên cứu khí hậu.
- NOAA Education — https://www.noaa.gov/education
  Tài nguyên giáo dục về khí quyển, đại dương và thời tiết.
- Worldbuilding Pasta — https://worldbuildingpasta.blogspot.com/
  Bài chuyên sâu về khí hậu, địa lý và worldbuilding khoa học.
- Artifexian — https://www.youtube.com/@Artifexian

## Sinh học, tiến hóa và thực vật
- PBS Eons — https://www.youtube.com/@eons
  Lịch sử sự sống, hóa thạch, tiến hóa và tuyệt chủng.
- Moth Light Media — https://www.youtube.com/@MothLightMedia
  Nội dung về tiến hóa và lịch sử sinh giới; nên đối chiếu nguồn trong mô tả video.
- Biblaridion — https://www.youtube.com/@Biblaridion
  Chuỗi *Alien Biospheres* tập trung speculative evolution.
- Animal Diversity Web — https://animaldiversity.org/
  Hồ sơ động vật và đặc điểm sinh học.
- Royal Botanic Gardens, Kew — https://www.kew.org/
  Thực vật và đa dạng sinh học.
- David Beerling, *The Emerald Planet*
  Vai trò của thực vật trong lịch sử Trái Đất.

## Sinh học giả định và nghệ thuật
- Wayne Barlowe, *Expedition*
  Thiết kế sinh vật ngoài hành tinh có logic hình thái; nguồn cảm hứng nghệ thuật.
- C. M. Kosemen, *All Tomorrows*
  Speculative evolution; không phải tài liệu khoa học.
- *Snaiad* — C. M. Kosemen
  Dự án thế giới giả tưởng và thiết kế sinh vật; dùng làm tham khảo sáng tạo.

## Đại dương và sự sống cực hạn
- NASA Ocean Worlds — https://science.nasa.gov/solar-system/ocean-worlds/
- NOAA Ocean Exploration — https://oceanexplorer.noaa.gov/
- Woods Hole Oceanographic Institution — https://www.whoi.edu/
- Deep Carbon Observatory — https://deepcarbon.net/
- NASA Astrobiology — https://astrobiology.nasa.gov/

## Công cụ bổ sung
- QGIS — https://qgis.org/ — tạo bản đồ địa lý và lớp dữ liệu.
- Blender — https://www.blender.org/ — dựng địa hình, quả địa cầu và cảnh quan.
- Obsidian — https://obsidian.md/ — liên kết các ghi chú Markdown.
- Git — https://git-scm.com/ — theo dõi lịch sử thay đổi lore.

## Ghi chú về chất lượng
- Một mô phỏng không phải bằng chứng rằng kịch bản có thể tồn tại tự nhiên; nó phản ánh giả định và mô hình được thiết lập.
- Các tác phẩm speculative evolution hữu ích để phát triển ý tưởng nhưng không nên trích dẫn như nghiên cứu sinh học.
- Nếu một ý tưởng quan trọng dựa vào bài báo cụ thể, hãy lưu DOI hoặc liên kết bài gốc thay vì chỉ lưu video tóm tắt.
