# 04 — Khí quyển, Khí hậu, Thời tiết và Mùa

## Phân biệt khái niệm
- **Thời tiết:** trạng thái ngắn hạn như mưa, bão, gió.
- **Khí hậu:** thống kê các điều kiện thời tiết trong thời gian dài.
- **Mùa:** chu kỳ biến đổi có tính lặp lại; thường do độ nghiêng trục và quỹ đạo, nhưng cũng có thể chịu ảnh hưởng của mưa theo mùa hoặc chu kỳ khí quyển.
- **Lịch:** hệ thống xã hội dùng để chia thời gian; không nhất thiết trùng hoàn toàn với mùa sinh học.

## Khí quyển
Ghi lại:
- Thành phần khí theo tỷ lệ phần trăm và khí vi lượng.
- Áp suất bề mặt.
- Nhiệt độ và biến thiên theo độ cao.
- Mây, bụi, aerosol và suất phản chiếu.
- Tốc độ gió, hướng gió chủ đạo và hoàn lưu toàn cầu.
- Khả năng hấp thụ tia cực tím/hồng ngoại và hiệu ứng nhà kính.
- Mưa, tuyết, mưa hóa chất, sương mù và bụi lắng.

**Lưu ý:** mật độ khí không chỉ do áp suất quyết định; nhiệt độ và khối lượng phân tử trung bình cũng quan trọng. Không khí dày có thể giúp tạo lực nâng lớn hơn cho cánh, nhưng lực cản cũng tăng. Khả năng bay phụ thuộc trọng lực, tốc độ, hình dạng, cơ bắp, mật độ khí và nhiều yếu tố khác.

## Mùa và chu kỳ
- Độ nghiêng trục là nguyên nhân quan trọng của mùa kiểu Trái Đất.
- Độ lệch tâm quỹ đạo làm năng lượng nhận được thay đổi theo quỹ đạo; mức độ ảnh hưởng tùy cấu hình.
- Khóa thủy triều có thể làm ngày/đêm khác thường.
- Hệ nhiều sao tạo chu kỳ ánh sáng phức tạp.
- Các chu kỳ khí quyển/đại dương có thể tạo mùa mưa-khô ngay cả khi độ nghiêng trục nhỏ.
- Chu kỳ Milankovitch trên Trái Đất là ví dụ về thay đổi quỹ đạo/trục ảnh hưởng phân bố bức xạ qua thời gian dài; không nên sao chép nguyên chu kỳ Trái Đất sang hành tinh khác.

## Từ khí hậu đến địa sinh học
- Nhiệt độ và nước kiểm soát mùa sinh trưởng.
- Mưa và địa hình tạo rừng, thảo nguyên, hoang mạc, đầm lầy.
- Nhiệt độ đại dương và vị trí lục địa định hình hải lưu.
- Mở/đóng eo biển có thể thay đổi dòng hải lưu, vận chuyển nhiệt và chất dinh dưỡng.
- Cháy tự nhiên, bão, đóng băng và hạn hán tạo áp lực chọn lọc.
- Khí nhà kính có thể bị sinh vật làm thay đổi, và sinh vật cũng phản hồi lại khí hậu.

## Cách thiết kế lịch
1. Chốt chu kỳ tự quay và chu kỳ quỹ đạo.
2. Định nghĩa ngày địa phương: độ dài, bình minh/hoàng hôn và số sao.
3. Xác định chu kỳ mùa khí hậu và mùa sinh học.
4. Tạo tên tháng/chu kỳ theo văn hóa cư dân sau khi đã có chu kỳ vật lý.
5. Đánh dấu các hiện tượng hiếm: nhật thực, mùa bão, đêm dài, di cư, mưa bào tử.
6. Kiểm tra xem mùa sinh trưởng có đủ dài cho cây trồng và sinh vật hay không.

## Nguồn
- NASA Climate: https://science.nasa.gov/climate-change/
- NASA GISS: https://www.giss.nasa.gov/
- NOAA Education: https://www.noaa.gov/education
- Worldbuilding Pasta: https://worldbuildingpasta.blogspot.com/
- Artifexian: https://www.youtube.com/@Artifexian

## Ý tưởng lore
- Mùa không được định nghĩa bởi nhiệt độ mà bởi chu kỳ bào tử phát tán.
- Một đại lục có mùa mưa kéo dài hàng năm do hoàn lưu khí quyển, trong khi lục địa khác trải qua chu kỳ khô dài.
- Sinh vật chỉ sinh sản trong những tuần có thành phần khí quyển đặc biệt sau mùa bão.
- Cư dân tính lịch theo “mùa di cư” của loài chủ chốt, không theo chu kỳ sao.

## Kiểm tra tính nhất quán
- [ ] Áp suất và thành phần khí được ghi rõ.
- [ ] Mùa có nguyên nhân vật lý/sinh thái xác định.
- [ ] Mưa và sa mạc phù hợp với địa hình và gió.
- [ ] Có giải thích cho nguồn nước và sự mất nước.
- [ ] Mỗi hiện tượng khí hậu lớn có tác động lên sinh vật hoặc đời sống.
