# 01 — Quy trình xây dựng Lore Hành tinh

## Mục tiêu
Xây từ nguyên nhân vật lý đến hệ quả sinh học và kể chuyện. Thứ tự này giảm việc phải sửa lại toàn bộ lore khi phát hiện một thông số nền mâu thuẫn.

## Quy trình đề xuất

### Bước 1 — Xác định vai trò của hành tinh
- Đây là hành tinh khởi đầu, vùng khám phá, nơi trú ẩn, thế giới nguy hiểm hay một bí ẩn?
- Người chơi cần cảm nhận điều gì: cô độc, kỳ dị, sinh sôi, suy tàn, hồi phục?
- Đặc điểm nào phải hiện rõ trong gameplay chứ không chỉ nằm trong tài liệu?

### Bước 2 — Chọn kiến trúc thiên văn
- Sao chủ hay hành tinh lang thang?
- Một sao hay hệ đa sao?
- Khoảng cách quỹ đạo, độ lệch tâm, chu kỳ quỹ đạo và tự quay.
- Có vệ tinh tự nhiên không? Có tác động thủy triều đáng kể không?
- Nguồn năng lượng bề mặt chính là ánh sao, địa nhiệt, hóa năng hay nguồn khác?

### Bước 3 — Chốt các thông số vật lý
- Khối lượng, bán kính, trọng lực bề mặt.
- Tỷ lệ đất liền/đại dương; độ sâu đại dương; độ cao địa hình.
- Áp suất và thành phần khí quyển.
- Từ trường, hoạt động địa chất, nguồn nhiệt bên trong.
- Có nước lỏng hay dung môi khác ở đâu, trong điều kiện nào?

### Bước 4 — Dựng địa chất và bản đồ
- Xác định mảng kiến tạo hoặc lý do hành tinh không có kiến tạo kiểu Trái Đất.
- Đặt núi, cao nguyên, bồn địa, rãnh sâu, núi lửa và đồng bằng.
- Kiểm tra đường thoát nước, nguồn trầm tích, bờ biển và vùng chắn mưa.
- Tạo ít nhất ba bản đồ thời gian: quá khứ xa, quá khứ gần và hiện tại.

### Bước 5 — Dựng khí hậu và mùa
- Tính ánh sáng nhận được theo sao chủ và quỹ đạo.
- Xác định hoàn lưu khí quyển, dòng biển, mưa, băng và sa mạc.
- Định nghĩa ngày, năm, mùa và các chu kỳ bất thường.
- Chọn một vài biến cố lớn có thể thay đổi khí hậu: núi lửa, va chạm, thay đổi eo biển, biến đổi khí nhà kính.

### Bước 6 — Định nghĩa nền hóa học của sự sống
- Dung môi chính: nước, hoặc giả thuyết khác cần giải thích kỹ.
- Các nguyên tố sẵn có và dạng hóa học có thể sử dụng.
- Nguồn năng lượng: ánh sáng, oxy hóa-khử, địa nhiệt gián tiếp hay hóa tổng hợp.
- Sinh vật lấy carbon, nitơ, phospho, lưu huỳnh và vi lượng từ đâu?
- Chất thải sinh học đi đâu và có độc với sinh vật khác không?

### Bước 7 — Thiết kế sinh vật sản xuất trước
- Thực vật, tảo, vi sinh vật quang hợp hoặc sinh vật hóa tổng hợp.
- Nguồn năng lượng và chất dinh dưỡng giới hạn tốc độ tăng trưởng.
- Xác định mùa sinh trưởng, cách phát tán, cạnh tranh và quan hệ cộng sinh.

### Bước 8 — Thiết kế động vật theo ngách sinh thái
- Ai ăn sinh vật sản xuất? Ai ăn chúng? Ai phân hủy xác?
- Mỗi loài cần giải quyết: vận động, trao đổi khí, điều hòa nhiệt, cảm giác, sinh sản và tránh bị ăn.
- Chỉ thêm đặc điểm giải phẫu nếu nó giúp sinh vật sống sót hoặc sinh sản trong môi trường cụ thể.

### Bước 9 — Dựng lịch sử tiến hóa
- Nguồn gốc sự sống và sinh vật đầu tiên.
- Các đợt xâm chiếm môi trường mới: nước nông, bờ biển, đất liền, lòng đất.
- Cô lập địa lý, cạnh tranh, tuyệt chủng hàng loạt và bức xạ thích nghi.
- Chọn vài hóa thạch chuyển tiếp hoặc loài tổ tiên để tạo chiều sâu lịch sử.

### Bước 10 — Dựng hệ sinh thái và tác động qua lại
- Chuỗi thức ăn, lưới thức ăn, ký sinh trùng, phân hủy và chu trình vật chất.
- Loài nào làm thay đổi đất, khí quyển, dòng nước hoặc cháy rừng?
- Có loài xâm lấn, dịch bệnh hay sự sụp đổ sinh thái không?

### Bước 11 — Chuyển khoa học thành kể chuyện
- Địa hình tạo ra tuyến đường, nơi trú ẩn và ranh giới.
- Mùa tạo ra lễ hội, di cư, mùa săn và thiếu lương thực.
- Loài nguy hiểm tạo ra chiến thuật, công cụ hoặc vùng cấm.
- Di tích địa chất/hóa thạch hé lộ lịch sử mà cư dân chưa hiểu.
- Biến dị sinh học có thể trở thành tiến hóa nhân vật, kỹ năng hoặc lựa chọn gameplay.

### Bước 12 — Kiểm tra nhất quán
- Có đủ năng lượng cho hệ sinh thái không?
- Khí quyển có phù hợp với áp suất, nhiệt độ và cơ chế hô hấp không?
- Sinh vật có nguồn thức ăn và con đường sinh sản khả thi không?
- Tốc độ biến đổi có phù hợp thang thời gian không?
- Nếu đổi một thông số nền, hệ quả nào phải thay đổi theo?

## Bảng quan hệ nhân quả mẫu
| Nguyên nhân | Hệ quả vật lý | Hệ quả sinh thái | Cơ hội kể chuyện/gameplay |
|---|---|---|---|
| Một mặt luôn hướng về sao do khóa thủy triều | Chênh lệch nhiệt ngày/đêm lớn, hoàn lưu mạnh | Sinh vật tập trung ở vùng chuyển tiếp hoặc dưới đất/nước | Hành trình theo dải hoàng hôn; bão thường trực |
| Dãy núi mới hình thành | Mưa nhiều ở sườn đón gió, khô hạn ở sườn khuất | Hai quần xã bị chia cắt và tiến hóa khác nhau | Hai nền văn hóa/loài có nguồn gốc chung |
| Ánh sáng yếu, đáy biển có nguồn hóa chất | Quang hợp hạn chế, hóa tổng hợp quan trọng | Chuỗi thức ăn quanh miệng phun thủy nhiệt | Hệ sinh thái phát sáng quanh các “ốc đảo” năng lượng |
| Khí hậu khô kéo dài | Đất mỏng, nước theo mùa | Hạt ngủ, rễ sâu, di cư, hoạt động về đêm | Tài nguyên theo mùa và tuyến di cư |

## Gợi ý cá nhân
Với RPG tiến hóa, nên chọn cho mỗi hành tinh **một quy luật sinh thái chủ đạo** và **một bí ẩn lịch sử**. Quy luật tạo gameplay lặp lại; bí ẩn tạo động lực khám phá. Không cần mọi hành tinh đều khác nhau ở tất cả thông số.
