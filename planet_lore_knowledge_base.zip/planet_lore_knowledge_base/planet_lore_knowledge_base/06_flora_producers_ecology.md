# 06 — Thực vật, Sinh vật sản xuất và Sinh thái

## Mở rộng khái niệm “thực vật”
Trong worldbuilding, sinh vật tạo ra vật chất hữu cơ không nhất thiết phải giống thực vật Trái Đất. Có thể gồm sinh vật quang hợp, tảo, vi sinh vật hóa tổng hợp, sinh vật cộng sinh hoặc những dạng hư cấu khác. Hãy xác định chức năng sinh thái trước khi chọn hình dáng.

## Các yếu tố quyết định hình thái
- **Ánh sáng:** cường độ, bước sóng, chu kỳ ngày đêm và độ sâu xuyên qua khí quyển/nước.
- **Nước:** lượng mưa, độ mặn, khả năng giữ nước, nước ngầm.
- **Dinh dưỡng:** nitơ, phospho, sắt và các nguyên tố vi lượng ở dạng có thể hấp thụ.
- **Nhiệt độ:** ảnh hưởng tốc độ phản ứng, enzyme, sinh trưởng và mùa sinh sản.
- **Gió và trọng lực:** ảnh hưởng chiều cao, hình dạng thân, phát tán phấn/bào tử.
- **Động vật ăn cỏ:** tạo áp lực phát triển gai, độc tố, vỏ, cộng sinh hoặc tăng trưởng nhanh.
- **Lửa, bão và lũ:** có thể chọn lọc khả năng tái sinh, hạt ngủ hoặc phát tán xa.

## Sinh vật sản xuất
- **Quang hợp:** cần nguồn ánh sáng, chất cho electron và nguyên liệu hóa học.
- **Hóa tổng hợp:** lấy năng lượng từ phản ứng hóa học; quan trọng ở môi trường tối như một số miệng phun thủy nhiệt và hang động.
- **Cộng sinh:** sinh vật lớn có thể dựa vào vi sinh vật cung cấp chất dinh dưỡng.
- **Sinh vật phân hủy:** tái chế vật chất từ xác và chất thải; nếu thiếu phân hủy, chu trình dinh dưỡng có thể bị nghẽn.

## Màu sắc và cấu trúc
- Màu sắc phải liên quan đến sắc tố, ánh sáng phản xạ/hấp thụ hoặc chức năng tín hiệu.
- Lá đen/tím có thể hợp lý trong một số phổ sáng, nhưng không tự động tối ưu cho mọi sao.
- Rễ sâu thường có lợi khi nước ở sâu, nhưng đắt về năng lượng và cấu trúc.
- Lá nhỏ, gai, lớp sáp hoặc thân mọng có thể giảm mất nước.
- Túi khí, mô xốp hoặc thân rỗng có thể hỗ trợ nổi hoặc trao đổi khí tùy môi trường.
- Cây khổng lồ cần vật liệu nâng đỡ, vận chuyển chất và nguồn năng lượng/dinh dưỡng đủ lớn.

## Tiến hóa qua thời gian
1. Sinh vật sản xuất sơ khai chiếm các môi trường có năng lượng.
2. Thay đổi địa chất mở ra ngách sinh thái mới.
3. Cô lập quần thể làm giảm trao đổi gene và tạo phân hóa.
4. Động vật, nấm và vi sinh vật thay đổi áp lực chọn lọc.
5. Tuyệt chủng mở ra ngách trống; nhóm còn sống có thể đa dạng hóa.
6. Sinh vật làm thay đổi đất, khí quyển, cháy rừng và chu trình dinh dưỡng, tạo phản hồi lên môi trường.

## Tạo một quần xã thực vật
Với mỗi vùng địa lý, xác định:
- Sinh vật sản xuất chủ đạo.
- Tầng cao/thấp và cấu trúc thảm thực vật.
- Mùa tăng trưởng, mùa ngủ hoặc mùa phát tán.
- Nguồn nước và dinh dưỡng.
- Động vật ăn thực vật và loài thụ phấn/phát tán.
- Sinh vật phân hủy.
- Một đặc điểm nhìn thấy từ xa và một cơ chế sinh thái khác thường.

## Nguồn
- David Beerling, *The Emerald Planet: How Plants Changed Earth's History*.
- PBS Eons: https://www.youtube.com/@eons
- Moth Light Media: https://www.youtube.com/@MothLightMedia
- Biblaridion, *Alien Biospheres*: https://www.youtube.com/@Biblaridion
- Royal Botanic Gardens, Kew: https://www.kew.org/
- Smithsonian National Museum of Natural History: https://naturalhistory.si.edu/

## Ý tưởng lore
- Rừng không “ăn ánh sáng” theo chu kỳ ngày mà mở tán theo chu kỳ gió giàu khoáng.
- Một đồng cỏ khô chỉ nảy mầm sau những trận bão mang vi sinh vật từ đại dương.
- Thảm thực vật trên hai sườn núi khác nhau vì hiệu ứng chắn mưa; cư dân có thể nhầm chúng là hai hành tinh khác nhau.
- Một loài cây phát tán hạt bằng cách bám vào động vật di cư, nên sự tuyệt chủng của động vật đó kéo theo suy giảm cả khu rừng.

## Tránh lỗi thường gặp
- Không tạo cây chỉ vì “đất giàu sắt” mà không giải thích cơ chế sinh học.
- Không coi ánh sáng đỏ/hồng ngoại là nguồn quang hợp dễ dàng nếu chưa xác định sắc tố và năng lượng photon.
- Không bỏ qua vi sinh vật, nấm và phân hủy.
- Không để hệ sinh thái có nhiều sinh vật lớn nhưng thiếu nền năng lượng và nguồn thức ăn.
