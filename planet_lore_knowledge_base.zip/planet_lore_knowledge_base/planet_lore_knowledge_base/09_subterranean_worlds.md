# 09 — Lòng đất, Hang động và Sinh quyển ngầm

## Các loại môi trường
- Hang karst do nước hòa tan đá dễ tan.
- Ống dung nham hình thành sau khi dòng dung nham rút đi.
- Khe nứt kiến tạo và vùng đá xốp.
- Mạng hang ngập nước.
- Sinh quyển vi sinh vật sâu trong đá, không nhất thiết có hang lớn để sinh vật đa bào di chuyển.

## Điều kiện môi trường
- Không có chu kỳ ánh sáng ngày/đêm ở sâu trong hang.
- Nhiệt độ có thể ổn định hơn bề mặt nhưng phụ thuộc độ sâu, dòng nước và nhiệt địa nhiệt.
- Oxy có thể thấp; CO₂, H₂S, methane hoặc radon có thể tích tụ tùy địa chất và thông gió.
- Nước, chất hữu cơ từ bề mặt, khoáng chất và phản ứng oxy hóa-khử quyết định năng suất sinh học.
- Hang có thể rất nghèo năng lượng; không nên mặc định có “rừng nấm khổng lồ” ở mọi nơi tối.

## Nguồn năng lượng và chuỗi thức ăn
- Vật chất hữu cơ từ bề mặt: lá, xác, phân, dòng nước.
- Hóa tổng hợp bởi vi sinh vật dựa trên phản ứng địa hóa.
- Cộng sinh giữa động vật và vi sinh vật.
- Sinh vật ăn mùn, lọc nước, săn mồi và phân hủy.
- Hệ sinh thái kín lâu dài cần cân bằng nguồn năng lượng, nguyên tố thiết yếu và chất thải.

## Thích nghi thường gặp ở sinh vật hang
- Giảm sắc tố hoặc giảm mắt ở một số dòng tiến hóa, không phải mọi loài hang đều mù.
- Tăng hóa cảm, xúc giác hoặc cảm nhận rung động khi có lợi.
- Trao đổi chất chậm có thể hỗ trợ sống trong môi trường thiếu thức ăn; tốc độ và khả năng nhịn đói khác nhau giữa loài.
- Cơ thể nhỏ có thể cần ít năng lượng hơn; cơ thể lớn cần nguồn thức ăn lớn và ổn định.
- Cơ thể dẹt, chi dài hoặc cơ quan bám có thể hữu ích tùy hình dạng hang và nền đá.

## Thiết kế bản đồ hang
1. Chọn nguồn gốc địa chất: karst, dung nham, khe nứt hay đào sinh học.
2. Xác định lối nước vào/ra và thông gió.
3. Đặt vùng giàu năng lượng, vùng nghèo năng lượng và ranh giới khí độc.
4. Thiết kế các nút sinh thái: hồ, giếng đứng, phòng hang lớn, dòng ngầm, vùng vi sinh vật.
5. Xác định cách loài di chuyển, sinh sản và tránh bị săn.
6. Xác định điều kiện khiến hang sụp, ngập hoặc mở ra bề mặt.

## Nguồn
- Deep Carbon Observatory: https://deepcarbon.net/
- NASA Astrobiology: https://astrobiology.nasa.gov/
- USGS Cave and Karst: https://www.usgs.gov/
- Smithsonian / nghiên cứu đa dạng sinh học: https://naturalhistory.si.edu/
- Các nghiên cứu về hang Movile (Romania) — dùng như ví dụ về hệ sinh thái hóa tổng hợp bị cô lập; hãy tra bài nghiên cứu cụ thể khi cần số liệu.

## Ý tưởng lore
- Sinh vật phát hiện người chơi qua rung động truyền trong vách đá; di chuyển chậm và dùng bề mặt mềm có thể giúp tránh bị phát hiện.
- Các vùng có khí nặng/khí độc tạo “lớp địa hình” vô hình; cư dân dùng sinh vật chỉ thị hoặc khoáng vật đổi màu để nhận biết.
- Một hang dung nham cổ có các lớp hóa thạch ghi lại những đợt tuyệt chủng liên tiếp.
- Mạng lưới hang được mở rộng bởi sinh vật đào hang, nhưng việc đào làm thay đổi dòng nước và đe dọa hệ sinh thái khác.

## Cảnh báo
- Đừng dùng “không có ánh sáng” như lời giải thích duy nhất cho màu trắng, mù hoặc cơ thể trong suốt; mỗi đặc điểm cần lịch sử tiến hóa và chức năng.
- “Ăn đá” thường là cách nói giản lược: sinh vật có thể khai thác năng lượng từ phản ứng hóa học liên quan đến khoáng chất, chứ không lấy năng lượng chỉ bằng cách nuốt đá.
- Đừng để hệ hang kín có sinh khối khổng lồ mà không chỉ ra nguồn năng lượng và vật chất.
