# 03 — Địa chất, Địa hình và Lịch sử bề mặt

## Kiến thức nền
Địa hình là kết quả của kiến tạo, núi lửa, va chạm, xói mòn, trầm tích, băng, dòng chảy và biến đổi hóa học. Trọng lực, thành phần vỏ, lượng nước và nhiệt bên trong quyết định quá trình nào chiếm ưu thế.

## Các yếu tố ảnh hưởng
- **Khối lượng và trọng lực:** ảnh hưởng khả năng giữ khí quyển, độ cao núi, dòng chảy và tải trọng lên sinh vật.
- **Nhiệt bên trong:** từ nhiệt còn sót lại khi hình thành, phân rã phóng xạ và biến dạng thủy triều.
- **Kiến tạo mảng:** tái chế vỏ, hình thành núi/rãnh, núi lửa và thay đổi vị trí lục địa. Không nên mặc định mọi hành tinh đá đều có kiến tạo mảng giống Trái Đất.
- **Nước và băng:** xói mòn, tạo thung lũng, đồng bằng châu thổ, hang động, sông băng.
- **Khí quyển:** gió và mưa tạo phong hóa; khí quyển dày/mỏng làm thay đổi cách bề mặt bị bào mòn.
- **Va chạm:** tạo hố va chạm và có thể làm biến đổi khí hậu/nguy cơ tuyệt chủng.
- **Khoáng vật:** ảnh hưởng màu đá, độ bền, hóa học đất và nguồn nguyên tố cho sinh vật.

## Quy trình dựng bản đồ
1. Vẽ các mảng kiến tạo hoặc các vùng vỏ ổn định.
2. Đánh dấu ranh giới hội tụ, phân kỳ và trượt ngang nếu có.
3. Đặt dãy núi, cung núi lửa, rãnh đại dương, cao nguyên và bồn địa.
4. Xác định hướng gió thịnh hành và sườn đón gió/khuất gió.
5. Vẽ mạng lưới sông từ vùng cao đến biển hoặc hồ nội lục; tránh sông chảy ngược độ cao nếu không có cơ chế đặc biệt.
6. Đặt trầm tích, đồng bằng, vùng ngập, bờ biển và sa mạc.
7. Kiểm tra các địa hình có nguồn gốc phù hợp với tuổi và hoạt động địa chất.
8. Tạo các phiên bản bản đồ ở nhiều mốc thời gian.

## Thang thời gian tham khảo
- **Giây đến năm:** động đất, phun trào, lũ, sạt lở, bão cát.
- **Hàng trăm đến hàng nghìn năm:** xói mòn, bồi tụ, dịch chuyển bờ biển, biến đổi hệ sinh thái.
- **Hàng chục nghìn đến triệu năm:** băng hà, thay đổi mực biển, nâng núi, biến đổi dòng hải lưu, phân hóa loài.
- **Hàng chục đến hàng trăm triệu năm:** mở/đóng đại dương, hợp nhất/tách siêu lục địa, thay đổi lâu dài của chu trình carbon.

Các khoảng trên là khung định hướng, không phải tốc độ cố định cho mọi hành tinh.

## Tác động lên sự sống
- Dãy núi cô lập quần thể và tạo vùng khí hậu khác nhau.
- Hiệu ứng chắn mưa làm sườn đón gió ẩm và sườn khuất gió khô hơn.
- Đảo và hồ cô lập có thể tạo loài đặc hữu.
- Núi lửa tạo đất mới và khoáng chất nhưng cũng gây phá hủy cục bộ.
- Mực biển thay đổi mở/đóng hành lang di cư.
- Hang dung nham, khe nứt và đá xốp có thể tạo môi trường sống kín.

## Nguồn
- GPlates: https://www.gplates.org/
- GPlates User Manual: https://www.gplates.org/docs/user-manual/
- Ancient Earth Globe: https://dinosaurpictures.org/ancient-earth
- USGS — Geology: https://www.usgs.gov/science/science-explorer/geology
- Smithsonian National Museum of Natural History: https://naturalhistory.si.edu/

## Ý tưởng lore
- Một dãy núi trẻ chia đôi loài tổ tiên thành hai dòng tiến hóa có tập tính và hình thái trái ngược.
- Một đại dương cổ đã biến mất, để lại hóa thạch sinh vật biển sâu giữa sa mạc.
- Một cao nguyên giàu kim loại khiến sinh vật phát triển vỏ khoáng hóa; việc này phải gắn với khả năng sinh học khai thác khoáng chất, không chỉ với kim loại có mặt trong đá.
- Một vùng địa hình đang nâng lên khiến các con sông đổi hướng, kéo theo sự sụp đổ của hệ sinh thái và nền văn minh phụ thuộc vào chúng.

## Checklist
- [ ] Nguồn gốc mỗi dãy núi/bồn địa đã rõ.
- [ ] Sông, hồ và bờ biển hợp lý.
- [ ] Khí hậu tương thích với độ cao và hướng gió.
- [ ] Lịch sử địa chất giải thích được các hóa thạch và khoáng vật.
- [ ] Có ít nhất một thay đổi địa chất tạo hệ quả sinh thái hoặc lịch sử.
