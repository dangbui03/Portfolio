# 10 — Lịch sử Sinh giới, Văn minh và Gameplay

## Từ sinh học đến lịch sử
Một hành tinh có chiều sâu khi môi trường không chỉ là phông nền mà còn là tác nhân làm thay đổi sinh vật và xã hội. Hãy xây dựng chuỗi nguyên nhân:
**biến cố → thay đổi môi trường → thay đổi sinh thái → thích nghi/tuyệt chủng → di cư/công nghệ/văn hóa → dấu tích hiện tại.**

## Lịch sử sinh giới
Tạo dòng thời gian gồm:
- Hình thành môi trường có thể hỗ trợ hóa học tiền sinh học.
- Xuất hiện sinh vật sơ khai (chi tiết có thể để bí ẩn).
- Sự xuất hiện của sinh vật sản xuất và thay đổi chu trình vật chất.
- Xâm chiếm môi trường mới: nước nông, đáy biển, đất liền, lòng đất.
- Các đợt phân hóa loài do cách ly địa lý.
- Tuyệt chủng và bức xạ thích nghi.
- Sự xuất hiện của loài có hành vi xã hội phức tạp hoặc trí tuệ, nếu có.

Không cần giải thích nguồn gốc sự sống đến từng phản ứng nếu nó không phục vụ câu chuyện. Có thể giữ một khoảng trống bí ẩn nhưng nên biết những hệ quả mà bí ẩn đó tạo ra.

## Tuyệt chủng và phục hồi
- Nguyên nhân có thể là biến đổi khí hậu, núi lửa, va chạm, mất môi trường sống, dịch bệnh hoặc thay đổi hóa học đại dương.
- Tuyệt chủng không xóa mọi loài như nhau; các nhóm có sinh cảnh rộng hoặc khả năng chịu đựng cao có thể sống sót.
- Phục hồi có thể kéo dài và tạo ra hệ sinh thái khác trước.
- Dấu tích: lớp đá, hóa thạch, vùng thiếu đa dạng, loài “hóa thạch sống” hoặc di tích văn hóa.

## Văn minh chịu ảnh hưởng bởi hành tinh
- Lịch và lễ hội có thể theo mùa, nhật thực, di cư hay chu kỳ phát quang.
- Nông nghiệp phụ thuộc đất, nước, độ dài mùa sinh trưởng và loài thụ phấn.
- Kiến trúc phụ thuộc trọng lực, gió, bão, nhiệt độ và vật liệu địa phương.
- Thương mại phụ thuộc đèo núi, eo biển, sông, băng và mùa.
- Y học phụ thuộc sinh lý loài, độc tố môi trường, vi sinh vật và chu trình dịch bệnh.
- Tôn giáo/triết học có thể phát triển từ hiện tượng thiên văn, nhưng nên tránh để mọi nền văn hóa có cùng phản ứng với một hiện tượng.

## Biến khoa học thành gameplay
Mỗi quy luật nên có:
- Tín hiệu báo trước cho người chơi.
- Tác động có thể học được.
- Lựa chọn hoặc kỹ năng đối phó.
- Phần thưởng cho việc hiểu môi trường.
- Hệ quả thay đổi theo hành động của người chơi.

Ví dụ:
| Quy luật | Tín hiệu | Gameplay |
|---|---|---|
| Bào tử phát tán theo gió mùa | Cây khép tán, động vật bắt đầu di cư | Đi theo đàn để tìm vùng mới hoặc tránh đám bào tử |
| Hang có vùng khí độc | Sinh vật chỉ thị biến mất, tinh thể đổi màu | Chọn đường vòng, chế tạo thiết bị đo hoặc dùng loài cộng sinh |
| Nhật thực kích hoạt săn mồi | Bầu trời tối dần, âm thanh hệ sinh thái đổi | Tìm nơi trú hoặc săn loài chỉ hoạt động trong bóng tối |
| Dãy núi đang nâng lên | Sạt lở và dòng sông đổi hướng | Tuyến đường cũ biến mất, hệ sinh thái chuyển vùng |

## Thiết kế 4–5 hành tinh đầu tiên
Để các hành tinh dễ nhớ, mỗi hành tinh nên có:
- Một gimmick sinh thái hoặc vật lý nổi bật.
- Một vòng lặp gameplay riêng.
- Một bí ẩn lịch sử.
- Một cách tiến hóa người chơi có thể cảm nhận.
- Một liên hệ với chủ đề chung của trò chơi.

Có thể dùng một hành tinh “bình thường” để dạy các quy luật cơ bản, sau đó tăng độ lạ. Một hành tinh không cần khác nhau ở mọi thông số; chỉ cần khác biệt đủ sâu ở một vài trục.

## Gợi ý cho các hành tinh đang thiếu
- **Hành tinh dưới nước:** thay đổi áp suất, ánh sáng, dòng chảy và nguồn năng lượng theo độ sâu; tiến hóa cảm giác và cơ thể theo từng tầng.
- **Hành tinh lòng đất:** ánh sáng không còn là trục chính; tài nguyên, khí, rung động, nước ngầm và địa chất tạo bản đồ.
- **Hành tinh không có sao chủ:** nguồn năng lượng cục bộ tạo các “ốc đảo” sống; khoảng tối rộng khiến di chuyển giữa chúng thành thử thách.
- **Hành tinh hồi phục:** dùng sự tái sinh sinh học làm cơ chế; cần có chi phí, giới hạn và dấu tích của tổn thương cũ để chủ đề không trở nên quá dễ dàng.
- **Hành tinh trắng dị thường:** giữ một quy luật vật lý bất thường làm trục, nhưng phân biệt rõ điều gì là khoa học giả định và điều gì là yếu tố siêu nhiên/lore.

## Checklist kể chuyện
- [ ] Môi trường tác động trực tiếp đến hành động người chơi.
- [ ] Có dấu tích của lịch sử lâu dài.
- [ ] Loài sinh vật có quan hệ sinh thái, không chỉ đứng riêng lẻ.
- [ ] Có ít nhất một điều người chơi hiểu sai lúc đầu rồi khám phá dần.
- [ ] Các quy luật được báo hiệu công bằng.
- [ ] Bí ẩn không phá vỡ những quy tắc đã thiết lập mà không có lý do.
