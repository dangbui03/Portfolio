# 08 — Hành tinh Đại dương, Vực sâu và Đại dương ngầm

## Phân biệt môi trường
- **Hành tinh đại dương:** bề mặt phần lớn hoặc hoàn toàn là nước; có thể có vùng nông, biển sâu hoặc lớp băng.
- **Đại dương ngầm:** nước lỏng nằm dưới lớp băng hoặc vỏ, được giữ lỏng nhờ nhiệt bên trong và/hoặc biến dạng thủy triều.
- **Vực sâu:** áp suất cao, ánh sáng thấp hoặc không có, nhiệt độ thường thấp ngoài các nguồn nhiệt cục bộ.
- **Miệng phun thủy nhiệt:** đưa chất hóa học và nhiệt từ bên trong ra môi trường nước; là nơi có thể tồn tại hệ sinh thái hóa tổng hợp.

## Nguồn năng lượng
- Ở vùng có ánh sáng, quang hợp có thể hỗ trợ nền sinh thái.
- Ở vùng tối, sinh vật hóa tổng hợp có thể dùng năng lượng từ phản ứng với hydrogen sulfide, hydrogen, methane hoặc hợp chất khác tùy điều kiện địa hóa.
- Nhiệt tự thân không tự động là nguồn năng lượng hóa học đủ dùng; cần phản ứng có chênh lệch năng lượng khả dụng.
- Xác và chất hữu cơ rơi từ tầng trên có thể nuôi sinh vật sâu, nhưng nguồn này giới hạn và phụ thuộc hệ sinh thái phía trên.

## Áp suất và sinh lý
- Áp suất tăng theo độ sâu; sinh vật phải tránh các cấu trúc/hoạt động phụ thuộc khí nén hoặc thích nghi với áp suất.
- Nhiệt độ, thức ăn, oxy hòa tan và cấu trúc mạng thức ăn ảnh hưởng kích thước và tốc độ trao đổi chất.
- “Khổng lồ hóa vực sâu” không phải quy luật chung; có loài lớn, loài nhỏ và nhiều chiến lược khác nhau.
- Ánh sáng có thể được dùng để dụ mồi, ngụy trang hoặc giao tiếp, nhưng chi phí phát quang phải được bù bằng lợi ích.
- Cảm nhận hóa học, dòng nước, rung động và điện trường có thể hữu ích trong môi trường tối.

## Thiết kế hệ sinh thái
1. Chọn nguồn năng lượng chính và vị trí của nó.
2. Xác định sinh vật sản xuất sơ cấp.
3. Định nghĩa chất dinh dưỡng, độc tố và chu trình vật chất.
4. Đặt sinh vật ăn lọc, ăn mùn, săn mồi và phân hủy.
5. Tạo vùng chuyển tiếp giữa môi trường giàu năng lượng và vùng nghèo năng lượng.
6. Kiểm tra khả năng sinh sản, phát tán ấu trùng hoặc di cư giữa các vùng.
7. Xác định biến cố địa chất/đại dương làm sụp đổ hoặc mở rộng hệ sinh thái.

## Đại dương ngầm: câu hỏi đặc biệt
- Lớp băng dày bao nhiêu? Có nứt, đối lưu hoặc trao đổi vật chất với bề mặt không?
- Nhiệt bên trong đến từ đâu?
- Có đáy biển đá hay đại dương nằm giữa các lớp băng?
- Nguồn chất oxy hóa và chất khử có gặp nhau không?
- Hệ sinh thái bị cô lập bao lâu? Có đủ nguyên liệu và năng lượng để duy trì sinh khối?
- Có thể có ánh sáng sinh học, nhưng ánh sáng sinh học không thay thế được nguồn năng lượng cho toàn hệ sinh thái nếu không có cơ chế sản xuất sơ cấp tương ứng.

## Nguồn
- NASA Ocean Worlds: https://science.nasa.gov/solar-system/ocean-worlds/
- NASA Astrobiology: https://astrobiology.nasa.gov/
- NOAA Ocean Exploration: https://oceanexplorer.noaa.gov/
- Woods Hole Oceanographic Institution: https://www.whoi.edu/
- NOAA — hydrothermal vents: https://oceanexplorer.noaa.gov/facts/vents.html

## Ý tưởng lore
- Một thành phố sinh vật tụ quanh miệng phun thủy nhiệt; khi hoạt động địa chất dịch chuyển, “thủ đô” sinh thái phải di cư.
- Một loài tạo ánh sáng để giao tiếp qua những vùng nước đục, nhưng tín hiệu bị kẻ săn mồi bắt chước.
- Một đại dương ngầm có chu kỳ thủy triều làm thay đổi khe nứt và đường đi, khiến bản đồ hang nước luôn thay đổi.
- Một quần thể bị cô lập trong hồ dưới băng có hình thái rất khác loài cùng tổ tiên ở biển mở.

## Gameplay
- Thay đổi áp suất theo độ sâu.
- Tầm nhìn bị giới hạn bởi ánh sáng và độ đục.
- Dòng chảy tạo tuyến di chuyển hoặc nguy hiểm.
- Ánh sáng sinh học vừa là công cụ vừa có thể tiết lộ vị trí.
- Nguồn nhiệt/hóa chất tạo “ốc đảo” tài nguyên hiếm.
