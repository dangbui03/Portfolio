# Planet Lore Knowledge Base
## Bộ khung xây dựng hệ sao, hành tinh và sự sống

Mục tiêu: tạo một thế giới có quan hệ nhân quả rõ ràng giữa thiên văn học, địa chất, khí hậu, hóa học, sinh học, lịch sử và gameplay. Đây là bộ tài liệu tham khảo và checklist, không phải bộ thông số bắt buộc.

## Cấu trúc
1. `01_lore_workflow.md` — quy trình tổng thể và thứ tự ra quyết định.
2. `02_star_systems.md` — sao chủ, hệ đa sao, quỹ đạo, ánh sáng và thủy triều.
3. `03_planet_geology.md` — cấu trúc hành tinh, kiến tạo mảng, địa hình và lịch sử địa chất.
4. `04_atmosphere_climate_seasons.md` — khí quyển, khí hậu, thời tiết, mùa và lịch.
5. `05_biochemistry_habitability.md` — nguyên tố, dung môi, chuyển hóa năng lượng và tính khả thi của sự sống.
6. `06_flora_producers_ecology.md` — thực vật, sinh vật sản xuất và mạng lưới sinh thái.
7. `07_fauna_anatomy_evolution.md` — động vật, giải phẫu, cảm giác, tiến hóa và hành vi.
8. `08_ocean_underwater_worlds.md` — hành tinh đại dương, vực sâu và đại dương ngầm.
9. `09_subterranean_worlds.md` — lòng đất, hang động và sinh quyển ngầm.
10. `10_history_civilization_gameplay.md` — lịch sử sinh giới, văn minh, bí ẩn và gameplay.
11. `11_reference_library.md` — thư viện nguồn và cách đánh giá nguồn.
12. `12_planet_design_template.md` — mẫu điền thông tin cho từng hành tinh.

## Cách dùng
- Đọc `01_lore_workflow.md` trước.
- Chốt các thông số cấp hành tinh trước khi thiết kế loài cụ thể.
- Dùng template ở `12_planet_design_template.md` cho mỗi hành tinh.
- Gắn nhãn thông tin: **[KHOA HỌC]**, **[SUY LUẬN]**, **[HƯ CẤU]**.
- Mỗi quyết định quan trọng nên ghi: nguyên nhân → hệ quả môi trường → thích nghi sinh học → hệ quả văn hóa/gameplay.

## Nguyên tắc thiết kế
- Không cần mô phỏng mọi thứ thật chính xác; cần nhất quán ở những yếu tố người chơi có thể nhận ra.
- Đừng thiết kế sinh vật chỉ từ hình dáng. Hãy bắt đầu từ môi trường, nguồn năng lượng, thức ăn, sinh sản và áp lực chọn lọc.
- Không coi các con số ví dụ là quy luật phổ quát. Tham số thực tế phụ thuộc vào nhiều điều kiện cùng lúc.
- Một hành tinh không có sao chủ vẫn có thể có nguồn sáng cục bộ, nhưng nền năng lượng và điều kiện bề mặt thường là thách thức lớn đối với sự sống phong phú.
