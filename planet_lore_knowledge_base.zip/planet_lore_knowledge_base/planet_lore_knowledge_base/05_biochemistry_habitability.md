# 05 — Hóa sinh, Nguyên tố và Điều kiện sự sống

## Nguyên tắc
Sự sống cần vật chất để tạo cấu trúc, nguồn năng lượng để duy trì các quá trình và môi trường cho phản ứng hóa học diễn ra. Việc một nguyên tố có nhiều trong vỏ hành tinh không đồng nghĩa sinh vật dễ hấp thụ nó: dạng hóa học, độ hòa tan, nhiệt độ, pH và chu trình địa hóa đều quan trọng.

## Nguyên tố và vai trò trên Trái Đất
- **Carbon (C):** tạo bộ khung của nhiều phân tử hữu cơ đa dạng.
- **Hydrogen và Oxygen (H, O):** quan trọng trong nước và nhiều phân tử sinh học.
- **Nitrogen (N):** thành phần của amino acid, nucleotide và nhiều phân tử thiết yếu.
- **Phosphorus (P):** liên quan đến ATP, acid nucleic và màng tế bào.
- **Sulfur (S):** có trong một số amino acid và tham gia nhiều phản ứng oxy hóa-khử.
- **Các nguyên tố vi lượng:** sắt, đồng, kẽm, molybdenum và những nguyên tố khác có thể đóng vai trò cofactor enzyme.

Đây là mô hình tham chiếu từ sự sống Trái Đất, không phải danh sách bắt buộc cho mọi dạng sống giả định.

## Nguồn năng lượng sinh học
- **Quang hợp:** chuyển năng lượng ánh sáng thành năng lượng hóa học.
- **Hóa tổng hợp:** lấy năng lượng từ phản ứng hóa học vô cơ/hữu cơ, thường gắn với môi trường như miệng phun thủy nhiệt.
- **Trao đổi chất oxy hóa-khử:** dùng chất cho và nhận electron phù hợp với môi trường.
- **Chuỗi thức ăn:** động vật thường lấy năng lượng bằng cách ăn sinh vật khác; không tự tạo ra năng lượng từ không khí.

# Cơ sở khoa học để hợp lý hóa Sinh lý học động vật

## Bài toán "Hít khí Nitơ ($N_2$)" và Sinh hóa thay thế

Trên Trái Đất, động vật dùng Oxy làm chất nhận điện tử cuối cùng vì phản ứng oxy hóa giải phóng lượng năng lượng rất lớn ($O_2$ có thế oxy hóa khử cao). Khí Nitơ tự nhiên tồn tại dạng liên kết ba ($N \equiv N$) cực kỳ bền vững (năng lượng liên kết lên tới $945\text{ kJ/mol}$), rất trơ về mặt hóa học ở nhiệt độ phòng.

Để sinh vật "hít và sử dụng $N_2$" một cách hợp lý về mặt nhiệt động lực học, bạn có 3 hướng giải thích:

* **Khí quyển giàu Hydro (Khử Nitơ tạo Amoniac):**
* **Phản ứng:** $N_2 + 3H_2 \rightarrow 2NH_3$ (tỏa nhiệt, $\Delta H^\circ = -92.4\text{ kJ/mol}$).
* **Cơ chế:** Trong bầu khí quyển nhiều $H_2$ và $N_2$, sinh vật hít cả hai khí này, dùng enzyme xúc tác kim loại đặc biệt trong phổi để khử $N_2$ thành $NH_3$ (Amoniac) nhằm tạo ra ATP, sau đó bài tiết Amoniac thể lỏng hoặc hơi.


* **Hấp thụ Nitơ trực tiếp làm vật liệu xây dựng mô (Biological Nitrogen Assimilation):**
* Thay vì dùng $N_2$ để tạo năng lượng hô hấp, sinh vật có một "phổi cố định đạm" chứa vi khuẩn cộng sinh hoặc bào quan tương tự enzyme Nitrogenase. Chúng không cần ăn quá nhiều đạm từ thực vật mà lấy trực tiếp Nitơ từ khí trời để tổng hợp protein và vỏ giáp chitin.


* **Hô hấp các hợp chất Nitơ hoạt tính ($NO_x$):**
* Khí quyển chứa oxit nitơ ($NO_2$, $N_2O$). Các khí này hoạt tính mạnh hơn $N_2$ rất nhiều và có thể đóng vai trò là chất oxy hóa thay thế cho $O_2$.

## Dung môi và hóa sinh thay thế
- **Nước:** dung môi tham chiếu tốt vì có tính phân cực và nhiều đặc tính phù hợp cho phản ứng sinh học.
- **Amoniac hoặc methane lỏng:** là các giả thuyết worldbuilding thú vị, nhưng đòi hỏi điều kiện nhiệt độ/áp suất phù hợp và hóa học khác đáng kể; bằng chứng cho sự sống như vậy hiện chưa được xác nhận.
- **Hệ silicon:** silicon có hóa học đa dạng nhưng không nên coi nó là bản thay carbon đơn giản; cần giải thích cấu trúc phân tử, dung môi, sản phẩm thải và nguồn năng lượng.

## Khí quyển và sinh lý
- Áp suất riêng phần của khí quan trọng hơn chỉ nhìn phần trăm khí.
- Khí độc ở nồng độ nhỏ có thể nguy hiểm; khí “trơ” không nhất thiết độc nhưng có thể gây thiếu oxy hoặc ảnh hưởng áp suất.
- Hô hấp cần bề mặt trao đổi khí, chênh lệch áp suất riêng phần và cơ chế vận chuyển.
- Mật độ khí cao có thể giúp bay, nhưng tăng lực cản; âm thanh truyền trong khí phụ thuộc nhiệt độ, thành phần và áp suất.
- Động vật lớn cần hỗ trợ cấu trúc, vận chuyển chất, tản nhiệt và nguồn thức ăn tương ứng.

## Xương, vỏ và khoáng hóa
- Canxi phosphate/carbonate, silica, chitin và protein là các ví dụ về vật liệu sinh học trên Trái Đất.
- Khoáng chất sẵn có chỉ là một phần của câu trả lời; sinh vật phải có cơ chế thu nhận, vận chuyển và kết tinh.
- Vật liệu rất cứng có thể giòn; vật liệu nhẹ có thể kém chịu lực. Cần cân bằng khối lượng, độ bền và chi phí tạo mô.
- Sinh vật giàu sắt hoặc kim loại nặng phải giải quyết độc tính, oxy hóa và chi phí sinh lý.

## Checklist hóa sinh
- [ ] Nguồn năng lượng sơ cấp.
- [ ] Dung môi và phạm vi nhiệt độ/áp suất.
- [ ] Nguồn carbon và các nguyên tố thiết yếu.
- [ ] Chất cho/nhận electron.
- [ ] Sản phẩm thải và chu trình tái chế.
- [ ] Cách sinh vật xử lý khí độc.
- [ ] Có cơ sở cho kích thước, màu sắc, xương/vỏ và tốc độ trao đổi chất.
- [ ] Các giả thuyết ngoài Trái Đất được đánh dấu [SUY LUẬN] hoặc [HƯ CẤU].

## Nguồn
- NASA Astrobiology: https://astrobiology.nasa.gov/
- NASA Astrobiology at NASA: https://science.nasa.gov/astrobiology/at-nasa/
- NASA Exoplanets: https://science.nasa.gov/exoplanets/
- OpenStax Biology 2e (sinh học nền tảng): https://openstax.org/details/books/biology-2e
- Earth Microbiome Project (bối cảnh vi sinh vật): https://earthmicrobiome.org/

B. Sách kinh điển về Cổ thực vật học & Tiến hóa giả định

    "The Emerald Planet: How Plants Changed Earth's History" – David Beerling: Cuốn sách kinh điển giải thích thực vật không đơn thuần sống trên Trái Đất, mà chính thực vật đã định hình khí quyển, độ ẩm và sự trôi dạt của các chu kỳ khí hậu qua hàng trăm triệu năm.

    "After Man: A Zoology of the Future" – Dougal Dixon: Tác phẩm mẫu mực về việc giả định Trái Đất 50 triệu năm sau: các lục địa trôi đi đâu, khí hậu biến đổi thế nào và sinh vật/thực vật tiến hóa ra sao để lấp đầy các ngách sinh thái mới.

3. Công cụ & Bản đồ mô phỏng thực hành

    Ancient Earth Globe (dinosaurpictures.org/ancient-earth):

        Mô hình 3D tương tác của Trái Đất từ 750 triệu năm trước đến nay. Bạn có thể chọn mốc thời gian (như kỷ Carbon, kỷ Jura) để xem các mảng kiến tạo dịch chuyển ra sao, các lục địa tách rời thế nào và thảm thực vật xanh phân bố ở đâu.

    GPlates (gplates.org):

        Phần mềm mã nguồn mở chuyên nghiệp của các nhà địa chất học dùng để mô phỏng sự chuyển động của các mảng kiến tạo theo thời gian. Nhiều tác giả sci-fi dùng công cụ này để tạo chuyển động địa hình thực tế cho bản đồ hành tinh giả tưởng.

    Songs of the Eons (Phần mềm/Dự án thế giới mở):

        Dự án tạo hành tinh mô phỏng đầy đủ từ kiến tạo mảng, dòng hải lưu, hoàn lưu khí quyển đến thảm thực vật tương ứng.    

## Ý tưởng lore
Một loài sống trong khí quyển giàu N₂ có thể dùng cộng sinh vi sinh vật để lấy nitơ xây mô, nhưng hô hấp vẫn dựa vào một phản ứng khác. Cộng sinh này có thể tạo ra điểm yếu: kháng sinh, mùa thiếu khoáng chất, hoặc một loài ký sinh chuyên tấn công vi sinh vật cộng sinh.
