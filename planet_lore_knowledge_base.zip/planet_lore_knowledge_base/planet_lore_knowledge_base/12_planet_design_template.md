# 12 — Template thiết kế hành tinh

> Sao chép file này cho mỗi hành tinh. Điền những mục có ảnh hưởng trực tiếp đến gameplay trước; phần còn lại có thể bổ sung sau.

## A. Bản sắc
- Tên hành tinh:
- Vai trò trong trò chơi:
- Cảm xúc/chủ đề:
- Quy luật sinh thái/vật lý nổi bật:
- Bí ẩn trung tâm:
- Gameplay độc nhất:
- Mức độ khoa học: [KHOA HỌC] / [SUY LUẬN] / [HƯ CẤU]

## B. Hệ sao
- Sao chủ và loại sao:
- Số sao:
- Khoảng cách quỹ đạo:
- Chu kỳ quỹ đạo:
- Độ lệch tâm:
- Độ dài ngày:
- Độ nghiêng trục:
- Vệ tinh/thủy triều:
- Khóa thủy triều/cộng hưởng:
- Nguồn năng lượng bề mặt:
- Bầu trời nhìn từ mặt đất:

## C. Thông số hành tinh
- Khối lượng/bán kính/trọng lực:
- Tỷ lệ đất liền và đại dương:
- Áp suất khí quyển:
- Thành phần khí:
- Nhiệt độ trung bình và biên độ:
- Từ trường:
- Hoạt động địa chất:
- Nước/dung môi:
- Mức độ chắc chắn của từng thông số:

## D. Địa chất và bản đồ
- Các mảng/vùng vỏ:
- Dãy núi:
- Bồn địa:
- Sông/hồ/biển:
- Sa mạc/băng/đầm lầy:
- Hang động và hệ thống ngầm:
- Tài nguyên khoáng:
- Các biến cố địa chất trong quá khứ:
- Bản đồ ở các mốc thời gian:

## E. Khí hậu và mùa
- Cơ chế tạo mùa:
- Các vùng khí hậu:
- Hướng gió chủ đạo:
- Dòng hải lưu:
- Mùa mưa/khô:
- Bão và hiện tượng cực đoan:
- Lịch địa phương:
- Tác động đến sinh vật và cư dân:

## F. Hóa sinh
- Dung môi:
- Nguồn carbon:
- Nguồn nitơ/phospho/lưu huỳnh:
- Nguồn năng lượng sinh học:
- Chất cho/nhận electron:
- Sản phẩm thải:
- Cơ chế xử lý khí độc:
- Vật liệu cơ thể (xương/vỏ/mô):
- Những giả định chưa được kiểm chứng:

## G. Sinh thái
### Sinh vật sản xuất
- Nhóm chính:
- Nguồn năng lượng:
- Sinh trưởng/sinh sản:
- Vai trò trong chu trình vật chất:

### Động vật
- Loài tiêu biểu:
- Thức ăn:
- Cách vận động:
- Hô hấp/tuần hoàn:
- Giác quan:
- Sinh sản:
- Kẻ săn mồi/ký sinh:

### Mạng lưới thức ăn
- Ai sản xuất vật chất hữu cơ?
- Ai ăn ai?
- Ai phân hủy xác?
- Chất dinh dưỡng được tái chế thế nào?
- Loài nào là loài chủ chốt?

## H. Lịch sử tiến hóa
- Môi trường sơ khai:
- Các bước tiến hóa lớn:
- Cách ly địa lý:
- Tuyệt chủng:
- Loài tổ tiên:
- Hóa thạch/di tích:
- Sự kiện khiến sinh thái hiện tại khác quá khứ:

## I. Sinh vật mẫu
- Tên:
- Môi trường:
- Vai trò sinh thái:
- Đặc điểm nổi bật:
- Lý do đặc điểm đó tiến hóa:
- Chi phí/điểm yếu:
- Hành vi:
- Tương tác với người chơi:
- Dấu hiệu nhận biết:
- Nguồn cảm hứng:

## J. Cư dân và lịch sử (nếu có)
- Loài trí tuệ:
- Nguồn thức ăn/năng lượng:
- Vật liệu và công nghệ:
- Lịch, mùa vụ, lễ hội:
- Tuyến thương mại/di cư:
- Huyền thoại dựa trên hiện tượng tự nhiên:
- Xung đột môi trường:
- Tàn tích của các thời đại trước:

## K. Checklist logic
- [ ] Có nguồn năng lượng đủ cho hệ sinh thái.
- [ ] Có chu trình vật chất và cơ chế phân hủy.
- [ ] Khí quyển phù hợp với sinh lý các loài.
- [ ] Địa hình phù hợp với địa chất và thủy văn.
- [ ] Mùa có nguyên nhân rõ.
- [ ] Tiến hóa có đủ thời gian và tổ tiên hợp lý.
- [ ] Các loài có vai trò sinh thái, thức ăn và sinh sản.
- [ ] Quy luật nổi bật tạo ra gameplay.
- [ ] Bí ẩn được gieo bằng dấu hiệu có thể tìm thấy.
- [ ] Mâu thuẫn khoa học được ghi rõ là giả định có chủ ý.

## L. Ý kiến phát triển
- Điểm mạnh của hành tinh:
- Điểm còn thiếu:
- Một biến cố quá khứ có thể giải thích hiện tại:
- Một loài biểu tượng:
- Một cơ chế gameplay:
- Một bí ẩn:
- Ba việc cần nghiên cứu tiếp:
