# 07 — Động vật, Giải phẫu và Tiến hóa

## Thiết kế từ chức năng thay vì từ hình ảnh
Mỗi loài nên được xác định qua sáu câu hỏi:
1. Sống ở đâu và điều kiện môi trường nào?
2. Ăn gì và lấy năng lượng bằng cách nào?
3. Di chuyển như thế nào?
4. Trao đổi khí, vận chuyển chất và điều hòa nhiệt ra sao?
5. Phát hiện con mồi, đồng loại và nguy hiểm bằng giác quan nào?
6. Sinh sản, chăm sóc con non và tránh tuyệt chủng bằng cách nào?

## Các yếu tố vật lý
- **Trọng lực:** ảnh hưởng tải trọng xương/cơ, chiều cao, bước đi và khả năng nhảy/bay.
- **Mật độ khí:** tác động lực nâng và lực cản; không thể suy ra khả năng bay chỉ từ “không khí đặc”.
- **Áp suất riêng phần:** quyết định hiệu quả trao đổi khí; tỷ lệ khí tổng thể chưa đủ để kết luận.
- **Nhiệt độ:** ảnh hưởng trao đổi chất, hoạt động enzyme và điều hòa thân nhiệt.
- **Độ nhớt và mật độ chất lỏng:** ảnh hưởng bơi, lơ lửng và hình dạng cơ thể dưới nước.
- **Ánh sáng:** ảnh hưởng mắt, sắc tố, tín hiệu thị giác và hoạt động ngày/đêm.
- **Địa hình:** tạo áp lực lên chân, móng, chi bám, cơ thể dẹt hoặc khả năng đào hang.

## Hình thái và vận động
- Đối xứng hai bên thường phù hợp với vận động có hướng; đối xứng tỏa tròn có lợi cho tương tác từ nhiều hướng, nhưng không có một kiểu hình bắt buộc.
- Số chi phải đi kèm cơ chế điều khiển, cơ, khớp và cách phân bố trọng lượng.
- Cơ thể thuôn giúp giảm lực cản trong một số môi trường; cơ thể dẹt có thể hữu ích trong khe hẹp hoặc bám nền.
- Cánh lớn có thể tạo lực nâng tốt nhưng cần năng lượng, cấu trúc và không gian cất cánh phù hợp.
- Cơ thể khổng lồ cần đủ thức ăn, vận chuyển chất và tản nhiệt; không phải môi trường sâu/lạnh nào cũng tạo ra sinh vật khổng lồ.

## Cảm giác
- **Thị giác:** cần ánh sáng và cơ quan tiếp nhận bước sóng phù hợp.
- **Thính giác/rung động:** có thể hữu ích trong nước, đất hoặc hang, nhưng truyền tín hiệu phụ thuộc môi trường.
- **Hóa cảm:** phát hiện mùi, pheromone, chất dinh dưỡng hoặc độc tố.
- **Cảm nhận điện trường:** có ví dụ ở động vật Trái Đất, nhất là môi trường nước.
- **Cảm nhận nhiệt:** có thể giúp phát hiện chênh lệch nhiệt, nhưng không nên mặc định mọi loài có thể “nhìn thấy hồng ngoại”.
- **Định vị bằng âm vang:** cần phát tín hiệu, nhận phản hồi và xử lý thời gian/đặc tính tín hiệu.

## Máu, xương và vật liệu cơ thể
- Hemoglobin gốc sắt và hemocyanin gốc đồng là ví dụ có thật về sắc tố hô hấp.
- Không nên gắn màu máu với một nguyên tố tùy ý; cần xác định phân tử vận chuyển khí và điều kiện hóa học.
- Xương/vỏ có thể dùng khoáng chất hoặc vật liệu hữu cơ khác nhau, nhưng mỗi vật liệu có đánh đổi về độ bền, trọng lượng, độ giòn và chi phí sinh học.
- Kim loại nặng có thể độc; lớp giáp kim loại đòi hỏi cơ chế thu nhận, khoáng hóa và quản lý độc tính.

## Tiến hóa và thời gian
- Đột biến và tái tổ hợp tạo biến dị; chọn lọc tự nhiên, phiêu bạt di truyền và dòng gene làm thay đổi quần thể.
- Cách ly địa lý có thể thúc đẩy hình thành loài.
- Tiến hóa không có mục tiêu định sẵn và không luôn tạo ra sinh vật “tốt hơn”; nó phụ thuộc môi trường và lịch sử.
- Hình thái phức tạp cần lịch sử phát triển, tổ tiên và cơ chế di truyền hợp lý.
- Tuyệt chủng hàng loạt có thể làm thay đổi mạnh hệ sinh thái, nhưng không đảm bảo mọi ngách sẽ được lấp đầy.

## Mẫu hồ sơ loài
- Tên / nhóm tiến hóa:
- Môi trường:
- Nguồn thức ăn:
- Vai trò trong lưới thức ăn:
- Cách vận động:
- Hô hấp và tuần hoàn:
- Giác quan chủ đạo:
- Sinh sản:
- Kẻ săn mồi / ký sinh:
- Thích nghi nổi bật:
- Chi phí hoặc điểm yếu của thích nghi:
- Tổ tiên giả định:
- Thang thời gian tiến hóa:
- Vai trò gameplay / câu chuyện:

## Nguồn
- PBS Eons: https://www.youtube.com/@eons
- Moth Light Media: https://www.youtube.com/@MothLightMedia
- Biblaridion, *Alien Biospheres*: https://www.youtube.com/@Biblaridion
- Smithsonian National Museum of Natural History: https://naturalhistory.si.edu/
- Animal Diversity Web: https://animaldiversity.org/
- Wayne Barlowe, *Expedition* (nguồn cảm hứng thiết kế sinh vật hư cấu).
- C. M. Kosemen, *All Tomorrows* (tác phẩm speculative evolution; dùng làm cảm hứng, không phải tài liệu khoa học).

## Ý tưởng lore
Một loài săn mồi trong hang có thể mất thị giác nhưng tăng cảm nhận rung động. Hãy đặt giới hạn: nền đá nào truyền rung tốt, mưa/bão có gây nhiễu không, và con mồi có thể đánh lạc hướng nó bằng cách nào. Giới hạn tạo chiến thuật gameplay tốt hơn một giác quan “toàn năng”.
